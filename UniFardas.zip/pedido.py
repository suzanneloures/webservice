class Pedido:
    Valor_Total = 0.00
    Order_Id = ''
    Payload_Id = ''
    From_Name = ''
    From_Internal_Id = ''
    Response = ''
